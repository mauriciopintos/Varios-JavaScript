//solicitar 2 numeros y hacer las operaciones basicas
let numero1 = parseInt(prompt("Dime el primer numero "));
let numero2 = parseInt(prompt("Dime el segundo numero "));
console.log("Procedo a calcular las operaciones basicas");
let suma = numero1 + numero2;
let resta = numero1 - numero2;
let multiplicacion = numero1 * numero2;
let division = numero1 / numero2;
console.log(`Suma = ${suma}`);
console.log(`Resta = ${resta}`);
console.log(`Multiplicacion = ${multiplicacion}`);
console.log(`Division = ${division}`);