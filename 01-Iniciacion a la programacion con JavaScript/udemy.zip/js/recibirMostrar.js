let nombre = prompt('Dime tu nombre');
document.write(`Tu nombre es ${nombre}`)
let numero1 = prompt('Dime el primer numero a sumar');
let numero2 = prompt('Dime el segundo numero a sumar');
let resultado = parseInt(numero1)+parseInt(numero2);
alert(`La suma es = ${resultado}`);