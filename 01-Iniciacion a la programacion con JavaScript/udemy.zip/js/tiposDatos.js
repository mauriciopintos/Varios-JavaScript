//Imprime en consola
console.log("Mi primer script de JavaScript!!!");
console.log("Esto es una cadena de texto");
console.log("Esto es un numero ",typeof(3));
console.log("Esto es un booleano ",typeof(false));
console.log("Esto es un numero ",typeof("3"));
console.log("Esto es un booleano ",typeof("false"));
document.write("Mostrando desde fichero script");